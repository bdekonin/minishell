/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   argumentchecker.c                                  :+:    :+:            */
/*                                                     +:+                    */
/*   By: bdekonin <bdekonin@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2020/11/02 14:11:58 by bdekonin      #+#    #+#                 */
/*   Updated: 2020/11/02 14:13:38 by bdekonin      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

int argumentchecker(t_vars *v, t_list *temp, t_list *list)
{
	while (temp)
	{
		
		temp = temp->next;
	}
}