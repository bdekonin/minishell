/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   argumentremover.c                                  :+:    :+:            */
/*                                                     +:+                    */
/*   By: bdekonin <bdekonin@student.codam.nl>         +#+                     */
/*                                                   +#+                      */
/*   Created: 2020/10/31 22:27:02 by bdekonin      #+#    #+#                 */
/*   Updated: 2020/11/01 17:59:40 by bdekonin      ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

#include "../minishell.h"

int argumentremover(t_vars *v, t_list *list)
{
	t_list *currcommand;
	t_list *nextcommand;
	
	if (list->next && !is_redirection(list->next->content))
		return (0);
	if (list->next == NULL || list->next->next == NULL)
		return (0);
	if (firstpipe(list) == NULL)
		return (0);
	if (ft_strncmp(list->next->content, "<", 1))
		return (0);
	currcommand = list;
	nextcommand = list->next->next->next;
	ft_lst_remove_one(&v->cmd, list->next->next);
	ft_lst_remove_one(&v->cmd, list->next);
	return (1);
}